# 🏥 HealthCare+ Web System

A web-based healthcare platform built using *HTML, CSS, and JavaScript, designed for **Patients, Doctors, and Hospitals*.  
The system provides a seamless healthcare workflow — from booking appointments to managing patient records, hospital data, and ambulance services.

---

## 🚀 Features

### 👤 *Patient/User Module*
- Login & Registration
- User Dashboard (Professional UI)
- Book Doctor Appointments
- View Upcoming Appointments
- Health Tips Section
- Contact Hospital with Map
- Ambulance Request & Tracking (Mock Data)
- Profile Management

### 🩺 *Doctor Module*
- Login & Registration
- Doctor Dashboard
- View Assigned Appointments
- Update Appointment Status (Confirmed / Pending)
- Access Patient Health Records
- Add Notes / Observations
- Profile Page

### 🏨 *Hospital Module*
- Login & Registration (with HFR validation)
- Hospital Dashboard
- Appointment Management
- Pharmacy (Basic Medicine Records)
- In-Patient Records (IPD)
- Billing Page (PDF Download enabled)

---

## 🗂 Project Structure
---

## 🛠 Tech Stack

| Category | Technology |
|----------|------------|
| Frontend | HTML, CSS, JavaScript |
| UI Icons | FontAwesome / Icons8 |
| UI Theme | Purple + White (Professional Healthcare) |
| Map (Mock) | Google Map Embed |
| PDF | jsPDF (for billing) |

---

## 🧪 How to Run
1. Install *Live Server* extension in VS Code  
2. Right-click index.html → *“Open with Live Server”*  

---

## 📌 Validations Implemented
- Email & Password validation
- Unique HFR (12-digit) validation for Hospital
- Switch between Login & Register Tabs
- Form-specific validation for each role

---

## ✨ Future Enhancements (for major project / panel impress)
- AI Chatbot using Python / ML (Symptom Analysis)
- Online Payment Gateway (Razorpay / Stripe)
- Real-time maps for Ambulance using Google Maps API
- Backend Integration (Firebase / Node.js + MongoDB)
- Appointment Reminders via SMS / Email
- Video Consultation Module

---

## 🙋‍♀ Author
*Developed by:* Ashritha R  
Project Version: Web Prototype (Phase-1)

---

### ✅ Status
This is the *frontend prototype version*.  
Backend + AI + Payment will be integrated in the next phase (Flutter / Firebase version already in progress).

---

### 🎯 Conclusion
This healthcare system demonstrates the *complete ecosystem approach* for digital healthcare —  
covering Patients, Doctors, and Hospitals through a unified interface with professional UI/UX.