import mongoose from "mongoose";

const hospitalSchema = new mongoose.Schema({
  name: { type: String, required: true },
  hfr: {
    type: String,
    required: true,
    unique: true,
    validate: {
      validator: (v) => /^[0-9]{12}$/.test(v),
      message: "Invalid HFR number — must be 12 digits.",
    },
  },
  password: { type: String, required: true },
});

export default mongoose.model("Hospital", hospitalSchema);