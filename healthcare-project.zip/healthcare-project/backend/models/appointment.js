import mongoose from "mongoose";

const appointmentSchema = new mongoose.Schema({
  patientName: String,
  doctorName: String,
  specialization: String,
  date: String,
  time: String,
  consultationType: String,
  contact: String,
  symptoms: String,
});

export default mongoose.model("Appointment", appointmentSchema);