import express from "express";
import Appointment from "../models/appointment.js";

const router = express.Router();

// Create (POST)
router.post("/", async (req, res) => {
  try {
    const appointment = new Appointment(req.body);
    await appointment.save();
    res.json({ success: true, message: "Appointment booked successfully!" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Read (GET)
router.get("/", async (req, res) => {
  const appointments = await Appointment.find();
  res.json(appointments);
});

export default router;