import express from "express";
import bcrypt from "bcryptjs";
import Doctor from "../models/doctor.js";

const router = express.Router();

// Register Doctor
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const existing = await Doctor.findOne({ email });
    if (existing)
      return res.json({ success: false, message: "Email already registered." });

    const hashed = await bcrypt.hash(password, 10);
    await new Doctor({ name, email, password: hashed }).save();
    res.json({ success: true, message: "Doctor registered successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Login Doctor
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const doctor = await Doctor.findOne({ email });
    if (!doctor) return res.json({ success: false, message: "Doctor not found." });

    const match = await bcrypt.compare(password, doctor.password);
    if (!match)
      return res.json({ success: false, message: "Incorrect password." });

    res.json({ success: true, message: "Login successful." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

export default router;