import express from "express";
import bcrypt from "bcryptjs";
import Hospital from "../models/hospital.js";

const router = express.Router();

// Register Hospital
router.post("/register", async (req, res) => {
  try {
    const { name, hfr, password } = req.body;

    if (!/^[0-9]{12}$/.test(hfr))
      return res.json({ success: false, message: "Invalid HFR number." });

    const existing = await Hospital.findOne({ hfr });
    if (existing)
      return res.json({ success: false, message: "Hospital already registered." });

    const hashed = await bcrypt.hash(password, 10);
    await new Hospital({ name, hfr, password: hashed }).save();
    res.json({ success: true, message: "Hospital registered successfully." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Login Hospital
router.post("/login", async (req, res) => {
  try {
    const { hfr, password } = req.body;
    const hospital = await Hospital.findOne({ hfr });
    if (!hospital)
      return res.json({ success: false, message: "Hospital not found." });

    const match = await bcrypt.compare(password, hospital.password);
    if (!match)
      return res.json({ success: false, message: "Incorrect password." });

    res.json({ success: true, message: "Login successful." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

export default router;