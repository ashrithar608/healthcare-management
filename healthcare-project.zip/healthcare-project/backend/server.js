// =============================
// 🌐 HEALTHCARE BACKEND SERVER
// =============================

import express from "express";
import mongoose from "mongoose";
import cors from "cors";

// ====== ROUTE IMPORTS ======
import appointmentRoutes from "./routes/appointmentRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import doctorRoutes from "./routes/doctorRoutes.js";
import hospitalRoutes from "./routes/hospitalRoutes.js";

// ====== APP INITIALIZATION ======
const app = express();
app.use(cors()); // allows frontend (e.g. localhost:5500) to access backend (localhost:5000)
app.use(express.json()); // parses incoming JSON data

// ====== MONGODB CONNECTION ======
mongoose
  .connect("mongodb://127.0.0.1:27017/healthcareDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB Connection Error:", err.message));

// ====== ROUTES ======
app.use("/api/appointments", appointmentRoutes);
app.use("/api/user", userRoutes);
app.use("/api/doctor", doctorRoutes);
app.use("/api/hospital", hospitalRoutes);

// ====== DEFAULT ROUTE ======
app.get("/", (req, res) => {
  res.send("🏥 Healthcare API is running successfully!");
});

// ====== START SERVER ======
const PORT = 5000;
app.listen(PORT, () => {
  console.log("🚀 Server running on http://localhost:"+PORT);
});