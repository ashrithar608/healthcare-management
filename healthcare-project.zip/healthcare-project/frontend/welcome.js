// Redirect user to dashboard page when clicking "Get Started"
document.getElementById("startBtn").addEventListener("click", () => {
  // You can later change this path when dashboard.html is ready
  window.location.href = "auth.html";
});