// ===== Toggle Edit Mode =====
const editBtn = document.getElementById("editBtn");
const saveBtn = document.getElementById("saveBtn");

editBtn.addEventListener("click", () => {
  const spans = document.querySelectorAll("span");
  spans.forEach((span) => {
    const input = document.createElement("input");
    input.value = span.textContent;
    input.classList.add("edit-input");
    span.replaceWith(input);
  });
  editBtn.disabled = true;
  saveBtn.disabled = false;
});

// ===== Save Changes =====
saveBtn.addEventListener("click", () => {
  const inputs = document.querySelectorAll(".edit-input");
  inputs.forEach((input) => {
    const span = document.createElement("span");
    span.textContent = input.value;
    input.replaceWith(span);
  });
  editBtn.disabled = false;
  saveBtn.disabled = true;
  alert("✅ Profile updated successfully!");
});

// ===== Go Back to Dashboard =====
function goBack() {
  window.location.href = "dashboard.html";
}
