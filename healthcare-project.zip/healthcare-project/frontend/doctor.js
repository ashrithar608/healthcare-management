const doctors = [
  { name: "Dr. Meera Patel", specialization: "Cardiologist", hospital: "Apollo", rating: 4.8, fee: 600 },
  { name: "Dr. Kavya Sharma", specialization: "Dermatologist", hospital: "SkinCare Clinic", rating: 4.6, fee: 500 },
  { name: "Dr. Arjun Mehta", specialization: "Orthopedic", hospital: "City Ortho", rating: 4.5, fee: 700 },
  { name: "Dr. Priya Nair", specialization: "Pediatrician", hospital: "Rainbow Kids", rating: 4.9, fee: 550 },
  { name: "Dr. Rohan Das", specialization: "Dentist", hospital: "Smile Dental", rating: 4.7, fee: 400 },
  { name: "Dr. Neha Iyer", specialization: "Neurologist", hospital: "BrainCare", rating: 4.8, fee: 800 },
  { name: "Dr. Sameer Khan", specialization: "Cardiologist", hospital: "HeartCare", rating: 4.4, fee: 650 },
  { name: "Dr. Pooja Verma", specialization: "Dentist", hospital: "Pearl Dental", rating: 4.5, fee: 450 },
  { name: "Dr. Ravi Patel", specialization: "Orthopedic", hospital: "OrthoPlus", rating: 4.6, fee: 700 },
  { name: "Dr. Aisha Ali", specialization: "Dermatologist", hospital: "Glow Clinic", rating: 4.7, fee: 550 },
  { name: "Dr. Mohit Agarwal", specialization: "Cardiologist", hospital: "Medicity", rating: 4.9, fee: 800 },
  { name: "Dr. Sneha Reddy", specialization: "Pediatrician", hospital: "LittleCare", rating: 4.8, fee: 600 },
  { name: "Dr. Ananya Rao", specialization: "Dentist", hospital: "Smile Bright", rating: 4.6, fee: 400 },
  { name: "Dr. Karan Malhotra", specialization: "Neurologist", hospital: "BrainPlus", rating: 4.7, fee: 750 },
  { name: "Dr. Tanvi Ghosh", specialization: "Dermatologist", hospital: "SkinHealth", rating: 4.9, fee: 600 },
];

const doctorList = document.getElementById("doctorList");
const modal = document.getElementById("bookingModal");
const appointmentsDiv = document.getElementById("appointments");
let selectedDoctor = null;

function renderDoctors(list) {
  if (!doctorList) return; // Safety check
  doctorList.innerHTML = "";
  list.forEach((doc, i) => {
    const card = document.createElement("div");
    card.className = "doctor-card";
    // Backticks already present – no change needed
    card.innerHTML = `
      <h3>${doc.name}</h3>
      <p>${doc.specialization}</p>
      <p>${doc.hospital}</p>
      <p>⭐ ${doc.rating} | ₹${doc.fee}</p>
      <button class="book-btn" onclick="openModal(${i})">Book Now</button>
    `;
    doctorList.appendChild(card);
  });
}

function openModal(index) {
  selectedDoctor = doctors[index];
  if (!selectedDoctor) {
    console.error(`Doctor not found at index: ${index}`);
    return;
  }
  const modalDoctorNameEl = document.getElementById("modalDoctorName");
  const modalSpecializationEl = document.getElementById("modalSpecialization");
  if (modalDoctorNameEl) modalDoctorNameEl.innerText = selectedDoctor.name;
  if (modalSpecializationEl) modalSpecializationEl.innerText = selectedDoctor.specialization;
  if (modal) modal.classList.remove("hidden");
}

function closeModal() {
  if (modal) modal.classList.add("hidden");
}

function confirmBooking() {
  const date = document.getElementById("appointmentDate")?.value || "";
  const time = document.getElementById("appointmentTime")?.value || "";
  const consultType = document.getElementById("consultType")?.value || "";
  const name = document.getElementById("patientName")?.value || "";
  const age = document.getElementById("patientAge")?.value || "";
  const gender = document.getElementById("patientGender")?.value || "";
  const phone = document.getElementById("patientPhone")?.value || "";
  const symptoms = document.getElementById("patientSymptoms")?.value || "";

  if (!date || !name || !phone) {
    alert("Please fill all required fields!");
    return;
  }

  const newAppointment = {
    doctorName: selectedDoctor.name,
    specialization: selectedDoctor.specialization,
    date,
    time,
    consultType,
    patient: { name, age, gender, phone, symptoms },
  };

  const existing = JSON.parse(localStorage.getItem("appointments")) || [];
  existing.push(newAppointment);
  localStorage.setItem("appointments", JSON.stringify(existing));

  closeModal();
  renderAppointments();
  // 🆕 FIX: Added backticks for template literal in alert
  alert(`✅ Appointment with ${selectedDoctor.name} booked for ${date} at ${time}.`);
}

function renderAppointments() {
  if (!appointmentsDiv) return;
  const appointments = JSON.parse(localStorage.getItem("appointments")) || [];
  // Backticks already present – no change needed
  appointmentsDiv.innerHTML = appointments
    .map(a => `
      <div class="appointment-card">
        <strong>${a.doctorName}</strong><br>
        ${a.specialization}<br>
        ${a.date} at ${a.time}<br>
        ${a.consultType}
      </div>
    `).join("");
}

function filterBy(spec) {
  if (spec === "All") renderDoctors(doctors);
  else renderDoctors(doctors.filter(d => d.specialization === spec));
}

const searchBarEl = document.getElementById("searchBar");
if (searchBarEl) {
  searchBarEl.addEventListener("input", e => {
    const val = e.target.value.toLowerCase();
    renderDoctors(doctors.filter(d => d.name.toLowerCase().includes(val) || d.specialization.toLowerCase().includes(val)));
  });
}

renderDoctors(doctors);
renderAppointments();
