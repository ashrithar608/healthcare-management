// Handle logout
function logout() {
  alert("You have logged out successfully!");
  window.location.href = "login.html"; // redirect to login page
}

// Handle book doctor click
function bookDoctor() {
  alert("Redirecting to Doctor Booking Page...");
  window.location.href = "book-doctor.html"; // upcoming page
}
function openProfile() {
  window.location.href = "profile.html";
}
function openAppointment() {
  window.location.href = "book-appointment.html";
}
function openDoctorPage() {
  window.location.href = "doctor.html";
}
function openHealthPage() {
  window.location.href = "health.html";
}
function openContactPage() {
  window.location.href = "contact.html";
}
function openAmbulancePage() {
  window.location.href = "ambulance.html";
}