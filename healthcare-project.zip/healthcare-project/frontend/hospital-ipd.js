const patients = [
  { patient: "Ravi Kumar", doctor: "Dr. Priya Sharma", room: "201-A", date: "2025-10-07", condition: "Stable", status: "Admitted" },
  { patient: "Sneha Patil", doctor: "Dr. Ramesh Gupta", room: "305-B", date: "2025-10-06", condition: "Critical", status: "Admitted" },
  { patient: "Kiran Rao", doctor: "Dr. Kiran Desai", room: "109-C", date: "2025-09-29", condition: "Stable", status: "Discharged" },
  { patient: "Meena Iyer", doctor: "Dr. S. Patil", room: "212-D", date: "2025-10-05", condition: "Critical", status: "Admitted" }
];

const tableBody = document.getElementById("patientTable");
const searchInput = document.getElementById("searchInput");
const addModal = document.getElementById("addModal");

function renderPatients() {
  tableBody.innerHTML = "";
  const search = searchInput.value.toLowerCase();

  patients
    .filter(p =>
      p.patient.toLowerCase().includes(search) ||
      p.doctor.toLowerCase().includes(search) ||
      p.room.toLowerCase().includes(search)
    )
    .forEach((p, i) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${p.patient}</td>
        <td>${p.doctor}</td>
        <td>${p.room}</td>
        <td>${p.date}</td>
        <td><span class="condition ${p.condition}">${p.condition}</span></td>
        <td><span class="status ${p.status}">${p.status}</span></td>
        <td>
          <button class="action-btn" onclick="dischargePatient(${i})">Discharge</button>
          <button class="action-btn" onclick="deletePatient(${i})">Delete</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
}

function openAddModal() {
  addModal.classList.remove("hidden");
}

function closeAddModal() {
  addModal.classList.add("hidden");
}

function addPatient() {
  const patient = document.getElementById("patientName").value.trim();
  const doctor = document.getElementById("doctorName").value.trim();
  const room = document.getElementById("roomNo").value.trim();
  const date = document.getElementById("admissionDate").value;
  const condition = document.getElementById("condition").value;

  if (!patient || !doctor || !room || !date) {
    alert("Please fill all fields.");
    return;
  }

  patients.push({ patient, doctor, room, date, condition, status: "Admitted" });
  renderPatients();
  closeAddModal();
}

function dischargePatient(index) {
  patients[index].status = "Discharged";
  renderPatients();
}

function deletePatient(index) {
  if (confirm("Are you sure you want to delete this record?")) {
    patients.splice(index, 1);
    renderPatients();
  }
}

function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Hospital logged out successfully!");
  window.location.href = "auth.html";
}

searchInput.addEventListener("input", renderPatients);
document.addEventListener("DOMContentLoaded", renderPatients);