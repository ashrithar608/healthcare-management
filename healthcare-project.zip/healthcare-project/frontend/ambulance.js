const ambulances = [
  { id: "AMB-101", driver: "Ravi Kumar", area: "MG Road", status: "On Duty" },
  { id: "AMB-102", driver: "Meena Patil", area: "Indiranagar", status: "On Duty" },
  { id: "AMB-103", driver: "Rajesh Singh", area: "Koramangala", status: "Off Duty" },
  { id: "AMB-104", driver: "Priya Nair", area: "Whitefield", status: "On Duty" },
  { id: "AMB-105", driver: "Kiran Rao", area: "BTM Layout", status: "On Duty" }
];

const ambulanceList = document.getElementById("ambulanceList");
const modal = document.getElementById("bookingModal");
const bookingSummary = document.getElementById("bookingSummary");
const bookingDetails = document.getElementById("bookingDetails");
const selectedAmbulanceText = document.getElementById("selectedAmbulance");
let selectedAmbulance = null;

function renderAmbulances() {
  if (!ambulanceList) return; // Safety check
  const searchInputEl = document.getElementById("searchInput");
  const search = searchInputEl?.value?.toLowerCase() || "";

  ambulanceList.innerHTML = "";
  ambulances
    .filter(a => a.driver.toLowerCase().includes(search) || a.area.toLowerCase().includes(search))
    .forEach(a => {
      const card = document.createElement("div");
      card.className = "ambulance-card";
      // 🆕 FIX: Use string template for conditional button (no JSX in vanilla JS)
      const bookButton = a.status === "On Duty" 
        ? `<button class="book-btn" onclick="openBooking('${a.id}', '${a.driver}', '${a.area}')">🚑 Book Now</button>`
        : "";
      card.innerHTML = `
        <h3>${a.id}</h3>
        <p><strong>Driver:</strong> ${a.driver}</p>
        <p><strong>Area:</strong> ${a.area}</p>
        <p><strong>Status:</strong> <span class="status ${a.status === "On Duty" ? "onduty" : "offduty"}">${a.status}</span></p>
        ${bookButton}
      `;
      ambulanceList.appendChild(card);
    });
}

function openBooking(id, driver, area) {
  selectedAmbulance = { id, driver, area };
  if (selectedAmbulanceText) {
    // 🆕 FIX: Added backticks for template literal
    selectedAmbulanceText.textContent = `Ambulance ${id} (${driver}) - ${area}`;
  }
  if (modal) modal.classList.remove("hidden");
}

function closeModal() {
  if (modal) modal.classList.add("hidden");
}

function confirmBooking() {
  const nameEl = document.getElementById("userName");
  const locationEl = document.getElementById("userLocation");
  const phoneEl = document.getElementById("userPhone");
  const name = nameEl?.value?.trim() || "";
  const location = locationEl?.value?.trim() || "";
  const phone = phoneEl?.value?.trim() || "";

  if (!name || !location || !phone) {
    alert("Please fill all details before booking.");
    return;
  }

  if (!selectedAmbulance) {
    alert("⚠ No ambulance selected.");
    return;
  }

  const eta = Math.floor(Math.random() * 15) + 5; // 5-20 minutes
  if (bookingSummary) bookingSummary.classList.remove("hidden");
  if (bookingDetails) {
    // Backticks already present – no change needed
    bookingDetails.innerHTML = `
      🚑 Ambulance <b>${selectedAmbulance.id}</b> (${selectedAmbulance.driver}) is on its way! <br>
      📍 Location: ${selectedAmbulance.area} <br>
      👤 Patient: ${name} <br>
      📞 Phone: ${phone} <br>
      ⏱ Estimated Arrival: ${eta} minutes
    `;
  }
  if (modal) modal.classList.add("hidden");
}

function downloadPDF() {
  if (!bookingSummary) {
    console.error("Booking summary element not found.");
    alert("⚠ Booking summary not available for PDF.");
    return;
  }
  // Assume html2pdf is loaded – if not, add <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script> to HTML
  html2pdf().from(bookingSummary).save("Ambulance_Booking.pdf").catch(err => {
    console.error("PDF generation error:", err);
    alert("⚠ Failed to generate PDF. Check console for details.");
  });
}

function goBack() {
  window.location.href = "udashboard.html";
}

const searchInputEl = document.getElementById("searchInput");
if (searchInputEl) {
  searchInputEl.addEventListener("input", renderAmbulances);
}

document.addEventListener("DOMContentLoaded", () => {
  renderAmbulances();
});
