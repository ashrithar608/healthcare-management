const medicines = [
  { name: "Paracetamol", category: "Tablet", quantity: 150, expiry: "2026-02-15", status: "InStock" },
  { name: "Amoxicillin", category: "Capsule", quantity: 20, expiry: "2025-12-01", status: "LowStock" },
  { name: "Cough Syrup", category: "Liquid", quantity: 0, expiry: "2025-06-10", status: "Expired" },
  { name: "Ibuprofen", category: "Tablet", quantity: 85, expiry: "2027-01-22", status: "InStock" },
  { name: "Insulin", category: "Injection", quantity: 10, expiry: "2025-08-12", status: "LowStock" }
];

const tableBody = document.getElementById("medicineTable");
const searchInput = document.getElementById("searchMedicine");
const addModal = document.getElementById("addModal");

function renderMedicines() {
  tableBody.innerHTML = "";
  const searchText = searchInput.value.toLowerCase();

  medicines
    .filter(m => m.name.toLowerCase().includes(searchText))
    .forEach((m, i) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${m.name}</td>
        <td>${m.category}</td>
        <td>${m.quantity}</td>
        <td>${m.expiry}</td>
        <td><span class="status ${m.status}">${m.status}</span></td>
        <td>
          <button class="action-btn" onclick="updateQuantity(${i})">Update</button>
          <button class="action-btn" onclick="deleteMedicine(${i})">Delete</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
}

function openAddModal() {
  addModal.classList.remove("hidden");
}

function closeAddModal() {
  addModal.classList.add("hidden");
}

function addMedicine() {
  const name = document.getElementById("medName").value.trim();
  const category = document.getElementById("medCategory").value.trim();
  const quantity = parseInt(document.getElementById("medQuantity").value);
  const expiry = document.getElementById("medExpiry").value;

  if (!name || !category || !quantity || !expiry) {
    alert("Please fill all fields.");
    return;
  }

  const status = quantity === 0
    ? "Expired"
    : quantity < 30
    ? "LowStock"
    : "InStock";

  medicines.push({ name, category, quantity, expiry, status });
  renderMedicines();
  closeAddModal();
}

function updateQuantity(index) {
  const newQty = prompt("Enter new quantity:", medicines[index].quantity);
  if (newQty !== null) {
    medicines[index].quantity = parseInt(newQty);
    medicines[index].status = newQty == 0
      ? "Expired"
      : newQty < 30
      ? "LowStock"
      : "InStock";
    renderMedicines();
  }
}

function deleteMedicine(index) {
  if (confirm("Delete this medicine?")) {
    medicines.splice(index, 1);
    renderMedicines();
  }
}

function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Hospital logged out successfully!");
  window.location.href = "auth.html";
}

searchInput.addEventListener("input", renderMedicines);
document.addEventListener("DOMContentLoaded", renderMedicines);