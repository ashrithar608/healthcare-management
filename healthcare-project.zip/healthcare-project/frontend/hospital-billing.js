let billItems = [];
const billBody = document.getElementById("billBody");

function addRow() {
  const row = {
    description: "",
    quantity: 1,
    price: 0,
    total: 0
  };
  billItems.push(row);
  renderTable();
}

function renderTable() {
  if (!billBody) return; // Safety check
  billBody.innerHTML = "";
  billItems.forEach((item, index) => {
    const row = document.createElement("tr");
    // Backticks already present – no change needed
    row.innerHTML = `
      <td><input type="text" value="${item.description}" onchange="updateItem(${index}, 'description', this.value)"></td>
      <td><input type="number" value="${item.quantity}" min="1" onchange="updateItem(${index}, 'quantity', this.value)"></td>
      <td><input type="number" value="${item.price}" min="0" onchange="updateItem(${index}, 'price', this.value)"></td>
      <td>₹${item.total}</td>
      <td><button class="add-btn" onclick="deleteRow(${index})">🗑</button></td>
    `;
    billBody.appendChild(row);
  });
  calculateTotals();
}

function updateItem(index, field, value) {
  if (index < 0 || index >= billItems.length) {
    console.error(`Invalid index: ${index}`);
    return;
  }
  billItems[index][field] = field === "description" ? value : parseFloat(value) || 0;
  billItems[index].total = billItems[index].quantity * billItems[index].price;
  renderTable();
}

function deleteRow(index) {
  if (index < 0 || index >= billItems.length) {
    console.error(`Invalid index: ${index}`);
    return;
  }
  billItems.splice(index, 1);
  renderTable();
}

function calculateTotals() {
  const subtotal = billItems.reduce((sum, i) => sum + (i.total || 0), 0);
  const tax = subtotal * 0.05;
  const discountPercent = parseFloat(document.getElementById("discount")?.value) || 0;
  const discount = (subtotal * discountPercent) / 100;
  const grand = subtotal + tax - discount;

  const subtotalEl = document.getElementById("subtotal");
  const taxEl = document.getElementById("tax");
  const grandTotalEl = document.getElementById("grandTotal");
  if (subtotalEl) {
    // 🆕 FIX: Added backticks for template literal
    subtotalEl.innerText = `₹${subtotal.toFixed(2)}`;
  }
  if (taxEl) {
    // 🆕 FIX: Added backticks for template literal
    taxEl.innerText = `₹${tax.toFixed(2)}`;
  }
  if (grandTotalEl) {
    // 🆕 FIX: Added backticks for template literal
    grandTotalEl.innerText = `₹${grand.toFixed(2)}`;
  }
}

function clearBill() {
  if (confirm("Clear all billing data?")) {
    billItems = [];
    renderTable();
  }
}

function generatePDF() {
  const billCardEl = document.getElementById("billCard");
  if (!billCardEl) {
    console.error("Bill card element not found.");
    alert("⚠ Bill content not available for PDF.");
    return;
  }
  const opt = {
    margin: 0.5,
    filename: "Hospital_Bill.pdf",
    image: { type: "jpeg", quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: "in", format: "a4", orientation: "portrait" }
  };
  // Assume html2pdf is loaded – if not, add <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script> to HTML
  html2pdf().from(billCardEl).set(opt).save().catch(err => {
    console.error("PDF generation error:", err);
    alert("⚠ Failed to generate PDF. Check console for details.");
  });
}

function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Hospital logged out successfully!");
  window.location.href = "auth.html";
}

const discountEl = document.getElementById("discount");
if (discountEl) discountEl.addEventListener("input", calculateTotals);

document.addEventListener("DOMContentLoaded", () => {
  const billDateEl = document.getElementById("billDate");
  if (billDateEl) billDateEl.value = new Date().toISOString().split("T")[0];
  renderTable();
});
