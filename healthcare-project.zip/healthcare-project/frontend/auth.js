// =============================
// 🌐 TAB SWITCHING
// =============================
const tabButtons = document.querySelectorAll(".tab-btn");
const formWrappers = document.querySelectorAll(".form-wrapper");

tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    tabButtons.forEach((b) => b.classList.remove("active"));
    formWrappers.forEach((f) => f.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
  });
});

// =============================
// 🔄 SWITCH BETWEEN LOGIN AND REGISTER
// =============================
const switches = document.querySelectorAll(".switch");
switches.forEach((sw) => {
  sw.addEventListener("click", () => {
    const type = sw.dataset.type;
    // Backticks already present – no change needed
    const regForm = document.getElementById(`${type}RegisterForm`);
    const logForm = document.getElementById(`${type}LoginForm`);

    if (regForm && logForm) {
      regForm.classList.toggle("hidden");
      logForm.classList.toggle("hidden");
    } else {
      console.error(`Forms not found for type: ${type}`); // Debug if IDs missing
    }
  });
});

// =============================
// 💬 UNIVERSAL SUCCESS HANDLER (Updated)
// =============================
function showSuccess(type, action) {
  const formattedType = type.charAt(0).toUpperCase() + type.slice(1);
  const formattedAction = action === "register" ? "Registered" : "Login";
  // 🆕 FIX: Added backticks for template literal in alert
  alert(`✅ ${formattedType} ${formattedAction} Successfully!`);

  // Redirect based on user type
  if (type === "user") {
    window.location.href = "udashboard.html";
  } else if (type === "doctor") {
    window.location.href = "doctor-dashboard.html";
  } else if (type === "hospital") {
    window.location.href = "hospital-dashboard.html";
  }
}

// =============================
// 👤 USER REGISTRATION / LOGIN
// =============================
document.getElementById("userRegisterForm").onsubmit = (e) => {
  e.preventDefault();
  // Basic validation (optional – add if you want to check fields)
  const name = document.getElementById("userName")?.value?.trim();
  const email = document.getElementById("userEmail")?.value?.trim();
  const password = document.getElementById("userPassword")?.value?.trim();
  if (!name || !email || !password) {
    alert("Please fill in all fields.");
    return;
  }
  showSuccess("user", "register");
};

document.getElementById("userLoginForm").onsubmit = (e) => {
  e.preventDefault();
  // Basic validation
  const email = document.getElementById("userLoginEmail")?.value?.trim();
  const password = document.getElementById("userLoginPassword")?.value?.trim();
  if (!email || !password) {
    alert("Please provide email and password.");
    return;
  }
  showSuccess("user", "login");
};

// =============================
// 🩺 DOCTOR REGISTRATION / LOGIN
// =============================
document.getElementById("doctorRegisterForm").onsubmit = (e) => {
  e.preventDefault();
  // Basic validation
  const name = document.getElementById("doctorName")?.value?.trim();
  const email = document.getElementById("doctorEmail")?.value?.trim();
  const password = document.getElementById("doctorPassword")?.value?.trim();
  if (!name || !email || !password) {
    alert("Please fill in all fields.");
    return;
  }
  showSuccess("doctor", "register");
};

document.getElementById("doctorLoginForm").onsubmit = (e) => {
  e.preventDefault();
  // Basic validation
  const email = document.getElementById("doctorLoginEmail")?.value?.trim();
  const password = document.getElementById("doctorLoginPassword")?.value?.trim();
  if (!email || !password) {
    alert("Please provide email and password.");
    return;
  }
  showSuccess("doctor", "login");
};

// =============================
// 🏥 HOSPITAL REGISTRATION / LOGIN
// =============================
document.getElementById("hospitalRegisterForm").onsubmit = (e) => {
  e.preventDefault();

  const name = document.getElementById("hospitalName")?.value?.trim();
  const hfr = document.getElementById("hospitalHfr")?.value?.trim();
  const password = document.getElementById("hospitalPassword")?.value?.trim();

  if (!name || !hfr || !password) {
    alert("Please fill in all fields.");
    return;
  }

  // Check HFR number (must be exactly 12 digits)
  const hfrPattern = /^[0-9]{12}$/;
  if (!hfrPattern.test(hfr)) {
    alert("❌ Invalid HFR Number! It must contain exactly 12 digits (0–9).");
    return;
  }

  showSuccess("hospital", "register");
};

document.getElementById("hospitalLoginForm").onsubmit = (e) => {
  e.preventDefault();
  const hfr = document.getElementById("hospitalLoginHfr")?.value?.trim();
  const password = document.getElementById("hospitalLoginPassword")?.value?.trim();

  if (!hfr || !password) {
    alert("Please provide HFR and password.");
    return;
  }

  showSuccess("hospital", "login");
};
