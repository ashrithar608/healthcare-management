// 🌸 Daily Motivational Quotes
const quotes = [
  "Take care of your body. It's the only place you have to live.",
  "Health is wealth, and happiness is its currency.",
  "Small daily improvements lead to long-lasting results.",
  "The greatest wealth is health.",
  "A healthy outside starts from the inside.",
  "Your body deserves your best care.",
  "The first wealth is health — cherish it daily.",
  "Eat well, move often, sleep deeply, and love freely."
];

// Display random quote each day
const quoteEl = document.getElementById("dailyQuote");
quoteEl.textContent = quotes[Math.floor(Math.random() * quotes.length)];

// 🌿 Health Tips Categories
const tips = [
  { title: "General Health", text: "Drink at least 2–3 liters of water daily and sleep for 7–8 hours to recharge your body." },
  { title: "Heart Health", text: "Avoid processed foods, reduce salt, and take a 30-minute walk every day to keep your heart active." },
  { title: "Dental Care", text: "Brush twice daily, floss regularly, and limit sugary snacks to keep your teeth strong." },
  { title: "Skin Care", text: "Apply sunscreen daily, hydrate often, and use mild cleansers for glowing skin." },
  { title: "Mental Health", text: "Take a few minutes each day for meditation or journaling to keep your mind at peace." },
  { title: "Nutrition", text: "Include colorful fruits and veggies in your diet for a natural vitamin boost." },
  { title: "Eye Care", text: "Follow the 20-20-20 rule: every 20 minutes, look 20 feet away for 20 seconds." },
  { title: "Exercise", text: "Do 30 minutes of physical activity daily — yoga, dance, or brisk walking all count!" },
  { title: "Sleep", text: "Maintain a consistent sleep schedule — your body loves routine." },
  { title: "Immunity", text: "Add Vitamin C and zinc-rich foods like citrus fruits and nuts to your diet." },
  { title: "Hydration", text: "Carry a water bottle everywhere; hydration keeps your skin and organs healthy." },
  { title: "Work-Life Balance", text: "Take breaks during work hours — stretch, move, or chat with a friend." },
  { title: "Stress Relief", text: "Breathe deeply, smile often, and stay connected with loved ones." },
  { title: "Posture", text: "Sit upright, adjust your screen height, and avoid hunching while working." },
  { title: "Hygiene", text: "Wash hands frequently and avoid touching your face unnecessarily." },
];

// Render health tips
const tipsContainer = document.getElementById("tipsContainer");
tipsContainer.innerHTML = tips
  .map(tip => `
    <div class="tip-card">
      <h3>${tip.title}</h3>
      <p>${tip.text}</p>
    </div>
  `)
  .join("");

// 💜 Optional: Animate new quote every few seconds
let i = 0;
setInterval(() => {
  i = (i + 1) % quotes.length;
  quoteEl.textContent = quotes[i];
}, 8000);