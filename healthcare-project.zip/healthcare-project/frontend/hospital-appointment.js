const appointments = [
  { patient: "Ravi Kumar", doctor: "Dr. Priya Sharma", date: "2025-10-09", time: "10:00 AM", status: "Confirmed" },
  { patient: "Sneha Patil", doctor: "Dr. Kiran Desai", date: "2025-10-09", time: "11:30 AM", status: "Pending" },
  { patient: "Kiran Rao", doctor: "Dr. Ramesh Gupta", date: "2025-10-09", time: "12:00 PM", status: "Cancelled" },
  { patient: "Meena Iyer", doctor: "Dr. Priya Sharma", date: "2025-10-10", time: "9:00 AM", status: "Confirmed" },
  { patient: "Rohit Verma", doctor: "Dr. S. Patil", date: "2025-10-10", time: "2:00 PM", status: "Pending" }
];

const tableBody = document.getElementById("appointmentsTable");
const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");
const addModal = document.getElementById("addModal");

function renderAppointments() {
  tableBody.innerHTML = "";
  const searchText = searchInput.value.toLowerCase();
  const filterStatus = statusFilter.value;

  appointments
    .filter(a =>
      (a.patient.toLowerCase().includes(searchText) ||
       a.doctor.toLowerCase().includes(searchText)) &&
      (filterStatus === "All" || a.status === filterStatus)
    )
    .forEach((a, i) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${a.patient}</td>
        <td>${a.doctor}</td>
        <td>${a.date}</td>
        <td>${a.time}</td>
        <td><span class="status ${a.status}">${a.status}</span></td>
        <td>
          <button class="action-btn" onclick="updateStatus(${i}, 'Confirmed')">Confirm</button>
          <button class="action-btn" onclick="updateStatus(${i}, 'Cancelled')">Cancel</button>
          <button class="action-btn" onclick="deleteAppointment(${i})">Delete</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
}

function updateStatus(index, newStatus) {
  appointments[index].status = newStatus;
  renderAppointments();
}

function deleteAppointment(index) {
  if (confirm("Delete this appointment?")) {
    appointments.splice(index, 1);
    renderAppointments();
  }
}

function openAddModal() {
  addModal.classList.remove("hidden");
}

function closeAddModal() {
  addModal.classList.add("hidden");
}

function addAppointment() {
  const patient = document.getElementById("patientName").value.trim();
  const doctor = document.getElementById("doctorName").value.trim();
  const date = document.getElementById("appointmentDate").value;
  const time = document.getElementById("appointmentTime").value;
  const status = document.getElementById("appointmentStatus").value;

  if (!patient || !doctor || !date || !time) {
    alert("Please fill all fields.");
    return;
  }

  appointments.push({ patient, doctor, date, time, status });
  renderAppointments();
  closeAddModal();
}

function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Hospital logged out successfully!");
  window.location.href = "auth.html";
}

searchInput.addEventListener("input", renderAppointments);
statusFilter.addEventListener("change", renderAppointments);
document.addEventListener("DOMContentLoaded", renderAppointments);