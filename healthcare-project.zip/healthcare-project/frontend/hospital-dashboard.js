function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("You have logged out successfully!");
  window.location.href = "auth.html";
}

// Example of dynamic stats update
document.addEventListener("DOMContentLoaded", () => {
  const stats = {
    doctors: 25,
    patients: 120,
    appointments: 18,
    beds: 5,
  };

  document.getElementById("doctorCount").textContent = stats.doctors;
  document.getElementById("patientCount").textContent = stats.patients;
  document.getElementById("appointmentCount").textContent = stats.appointments;
  document.getElementById("bedCount").textContent = stats.beds;
});