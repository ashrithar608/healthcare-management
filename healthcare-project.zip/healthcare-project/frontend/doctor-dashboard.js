// Dummy data for appointments
const todayAppointments = [
  { name: "Ravi Kumar", time: "10:00 AM", type: "In-person", status: "Confirmed" },
  { name: "Sneha Patil", time: "11:30 AM", type: "Online", status: "Pending" },
  { name: "Kiran Desai", time: "1:00 PM", type: "In-person", status: "Confirmed" },
  { name: "Meena Reddy", time: "3:00 PM", type: "Online", status: "Completed" },
  { name: "Arjun Rao", time: "5:00 PM", type: "In-person", status: "Confirmed" }
];

// Populate appointments table
const appointmentTable = document.getElementById("appointmentTable");

todayAppointments.forEach(app => {
  const row = document.createElement("tr");
  row.innerHTML = `
    <td>${app.name}</td>
    <td>${app.time}</td>
    <td>${app.type}</td>
    <td>${app.status}</td>
  `;
  appointmentTable.appendChild(row);
});

// Navigation between pages
function openPage(page) {
  window.location.href = "doctor-profile.html";
}
function openPage(page) {
  window.location.href = "doctor-appointments.html";
}
function openPage(page) {
  window.location.href = "doctor-records.html";
}

// Logout
function logout() {
  alert("Doctor logged out successfully!");
  window.location.href = "auth.html";
}