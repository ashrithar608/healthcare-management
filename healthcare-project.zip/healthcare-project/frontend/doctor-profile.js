// Dummy doctor profile data
const doctorProfile = {
  name: "Dr. Priya Sharma",
  email: "priya.sharma@lifeplus.in",
  specialization: "Cardiologist",
  hospital: "LifePlus Multispeciality Hospital",
  fees: "800",
  availability: "Mon–Sat, 9 AM – 5 PM",
  experience: "12 years",
};

// Load data on page start
window.onload = () => {
  document.getElementById("name").value = doctorProfile.name;
  document.getElementById("email").value = doctorProfile.email;
  document.getElementById("specializationInput").value = doctorProfile.specialization;
  document.getElementById("hospital").value = doctorProfile.hospital;
  document.getElementById("fees").value = doctorProfile.fees;
  document.getElementById("availability").value = doctorProfile.availability;
  document.getElementById("experience").value = doctorProfile.experience;
};

// Enable edit mode
document.getElementById("editBtn").addEventListener("click", () => {
  const inputs = document.querySelectorAll("#profileForm input");
  inputs.forEach((input) => input.removeAttribute("readonly"));
  document.getElementById("saveBtn").classList.remove("hidden");
  document.getElementById("editBtn").classList.add("hidden");
});

// Save updated info
document.getElementById("profileForm").addEventListener("submit", (e) => {
  e.preventDefault();

  // Capture updated info
  const updatedProfile = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    specialization: document.getElementById("specializationInput").value,
    hospital: document.getElementById("hospital").value,
    fees: document.getElementById("fees").value,
    availability: document.getElementById("availability").value,
    experience: document.getElementById("experience").value,
  };

  console.log("Updated Profile:", updatedProfile);

  // Lock fields again
  const inputs = document.querySelectorAll("#profileForm input");
  inputs.forEach((input) => input.setAttribute("readonly", true));

  document.getElementById("saveBtn").classList.add("hidden");
  document.getElementById("editBtn").classList.remove("hidden");

  alert("✅ Profile updated successfully!");
});

// Navigation functions
function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Doctor logged out successfully!");
  window.location.href = "auth.html";
}