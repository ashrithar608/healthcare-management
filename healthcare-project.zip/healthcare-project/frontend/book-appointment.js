/* ------------ Dummy doctor data ------------ */
const doctors = [
  {
    id: "d1",
    name: "Dr. Meera Patel",
    specialization: "Cardiologist",
    clinic: "City Heart Center",
    rating: 4.8,
    reviews: 124,
    experience: 12, // years
    fee: 600,
    nextAvailable: "2025-10-12T16:00:00"
  },
  {
    id: "d2",
    name: "Dr. Kavya Sharma",
    specialization: "Dermatologist",
    clinic: "SkinCare Clinic",
    rating: 4.6,
    reviews: 92,
    experience: 8,
    fee: 450,
    nextAvailable: "2025-10-11T11:30:00"
  },
  {
    id: "d3",
    name: "Dr. Ramesh Iyer",
    specialization: "General Physician",
    clinic: "Wellness Clinic",
    rating: 4.4,
    reviews: 210,
    experience: 15,
    fee: 350,
    nextAvailable: "2025-10-10T09:00:00"
  },
  {
    id: "d4",
    name: "Dr. Sanya Rao",
    specialization: "Dentist",
    clinic: "Smile Studio",
    rating: 4.7,
    reviews: 58,
    experience: 6,
    fee: 400,
    nextAvailable: "2025-10-13T14:00:00"
  }
];

/* ------------ State & UI refs ------------ */
const filterChipsEl = document.getElementById("filterChips");
const resultsEl = document.getElementById("results");
const globalSearch = document.getElementById("globalSearch");
const sortSelect = document.getElementById("sortSelect");
const upcomingList = document.getElementById("upcomingList");
const modal = document.getElementById("modal");
const modalClose = document.getElementById("modalClose");
const modalDoctorTitle = document.getElementById("modalDoctorTitle");
const apptDate = document.getElementById("apptDate");
const timeSlotsEl = document.getElementById("timeSlots");
const consultType = document.getElementById("consultType");
const patName = document.getElementById("patName");
const patAge = document.getElementById("patAge");
const patGender = document.getElementById("patGender");
const patPhone = document.getElementById("patPhone");
const patSymptoms = document.getElementById("patSymptoms");
const feeAmount = document.getElementById("feeAmount");
const confirmBtn = document.getElementById("confirmBtn");
const cancelBtn = document.getElementById("cancelBtn");
const confirmToast = document.getElementById("confirmToast");

let activeFilters = new Set();
let currentDoctor = null;
let selectedSlot = null;

/* ------------ Init  ------------ */
const specializations = Array.from(new Set(doctors.map(d => d.specialization)));

function buildFilterChips() {
  if (!filterChipsEl) return; // Safety check
  filterChipsEl.innerHTML = "";
  const allChip = chipEl("All", true);
  allChip.addEventListener("click", () => {
    activeFilters.clear();
    renderDoctors();
    setActiveChip(allChip);
  });
  filterChipsEl.appendChild(allChip);

  specializations.forEach(spec => {
    const c = chipEl(spec);
    c.addEventListener("click", () => {
      if (activeFilters.has(spec)) activeFilters.delete(spec); else activeFilters.add(spec);
      // remove All selection
      setActiveChip(null);
      renderDoctors();
      updateChipStates();
    });
    filterChipsEl.appendChild(c);
  });
  updateChipStates();
}

function chipEl(text, active = false) {
  const el = document.createElement("div");
  el.className = "chip" + (active ? " active" : "");
  el.textContent = text;
  return el;
}

function updateChipStates() {
  if (!filterChipsEl) return;
  const chips = filterChipsEl.querySelectorAll(".chip");
  chips.forEach(ch => {
    const t = ch.textContent;
    if (t === "All") {
      ch.classList.toggle("active", activeFilters.size === 0);
    } else {
      ch.classList.toggle("active", activeFilters.has(t));
    }
  });
}

/* ------------ Render doctors ------------ */
function renderDoctors() {
  if (!resultsEl) return;
  const q = globalSearch?.value?.trim().toLowerCase() || "";
  let list = doctors.filter(d => {
    // filter by active filters
    if (activeFilters.size > 0 && !activeFilters.has(d.specialization)) return false;
    // search name or specialization
    if (q && !(d.name.toLowerCase().includes(q) || d.specialization.toLowerCase().includes(q))) return false;
    return true;
  });

  // sort
  const sortBy = sortSelect?.value || "";
  if (sortBy === "rating") list.sort((a, b) => b.rating - a.rating);
  else if (sortBy === "experience") list.sort((a, b) => b.experience - a.experience);
  else if (sortBy === "fee_low") list.sort((a, b) => a.fee - b.fee);
  else list.sort((a, b) => new Date(a.nextAvailable) - new Date(b.nextAvailable));

  // render
  resultsEl.innerHTML = "";
  if (list.length === 0) {
    // 🆕 FIX: Use string for innerHTML (not JSX)
    resultsEl.innerHTML = '<p class="muted">No doctors found. Try clearing filters or search.</p>';
    return;
  }

  list.forEach(d => {
    const card = document.createElement("div");
    card.className = "doctor-card";
    // 🆕 FIX: Use backticks for template literal in innerHTML
    card.innerHTML = `
      <div class="doc-avatar">${initials(d.name)}</div>
      <div class="doc-meta">
        <h4>${d.name}</h4>
        <p>${d.specialization} • ${d.clinic}</p>
        <div class="doc-stats">
          <div>⭐ ${d.rating} (${d.reviews})</div>
          <div>🧾 ${d.experience} yrs</div>
          <div class="fee">₹ ${d.fee}</div>
        </div>
        <p class="muted" style="margin-top:8px">Next: ${formatDateTime(d.nextAvailable)}</p>
      </div>
      <div class="doctor-actions">
        <button class="btn" onclick="openBooking('${d.id}')">Book Now</button>
      </div>
    `;
    resultsEl.appendChild(card);
  });
}

/* utils */
function initials(name) {
  return name.split(" ").map(s => s[0]).slice(0, 2).join("").toUpperCase();
}

function formatDateTime(iso) {
  const dt = new Date(iso);
  if (isNaN(dt.getTime())) {
    console.error(`Invalid date: ${iso}`); // Safety for invalid dates
    return "Invalid date";
  }
  // 🆕 FIX: Add locale argument to toLocaleString
  return dt.toLocaleString('en-US', { dateStyle: "medium", timeStyle: "short" });
}

/* ------------ Search & UI events ------------ */
if (globalSearch) globalSearch.addEventListener("input", () => renderDoctors());
if (sortSelect) sortSelect.addEventListener("change", () => renderDoctors());

/* ------------ Booking modal logic ------------ */
function openBooking(docId) {
  const doc = doctors.find(d => d.id === docId);
  if (!doc) {
    console.error(`Doctor not found: ${docId}`);
    return;
  }
  currentDoctor = doc;
  selectedSlot = null;
  if (modalDoctorTitle) {
    // 🆕 FIX: Use backticks for template literal
    modalDoctorTitle.textContent = `Book with ${doc.name} — ${doc.specialization}`;
  }
  if (feeAmount) feeAmount.textContent = `₹ ${doc.fee}`;
  // set date min to today
  const today = new Date().toISOString().split("T")[0];
  if (apptDate) {
    apptDate.min = today;
    apptDate.value = today;
  }

  // populate time slots (simple generation around nextAvailable)
  generateTimeSlots(doc.nextAvailable);

  if (modal) {
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
  }
}

function generateTimeSlots(nextIso) {
  if (!timeSlotsEl) return;
  timeSlotsEl.innerHTML = "";
  // sample slots: nextAvailable +/- some hours
  const base = new Date(nextIso);
  if (isNaN(base.getTime())) {
    console.error(`Invalid base date: ${nextIso}`);
    return;
  }
  const slots = [];
  for (let i = 0; i < 6; i++) {
    const s = new Date(base.getTime() + i * 30 * 60000); // every 30min
    slots.push(s);
  }
  slots.forEach(s => {
    const chip = document.createElement("div");
    chip.className = "chip slot";
    // 🆕 FIX: Use backticks for template literal
    chip.textContent = s.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    chip.addEventListener("click", () => {
      // toggle
      timeSlotsEl.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      selectedSlot = s.toISOString();
    });
    timeSlotsEl.appendChild(chip);
  });
}

/* modal controls */
if (modalClose) modalClose.addEventListener("click", closeModal);
if (cancelBtn) cancelBtn.addEventListener("click", closeModal);

function closeModal() {
  if (modal) {
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
  }
  currentDoctor = null;
  selectedSlot = null;
}

/* Confirm booking */
if (confirmBtn) {
  confirmBtn.addEventListener("click", () => {
    // basic validation
    if (!currentDoctor) {
      alert("No doctor selected");
      return;
    }
    if (!selectedSlot) {
      alert("Please select a time slot.");
      return;
    }
    if (!patName?.value?.trim() || !patPhone?.value?.trim()) {
      alert("Please enter patient name and phone.");
      return;
    }
    // create appointment object
    const appt = {
      id: "appt_" + Date.now(),
      doctorId: currentDoctor.id,
      doctorName: currentDoctor.name,
      specialization: currentDoctor.specialization,
      date: selectedSlot,
      consultType: consultType?.value || "In-person",
      patient: {
        name: patName.value.trim(),
        age: patAge?.value?.trim() || "",
        gender: patGender?.value || "",
        phone: patPhone.value.trim(),
        symptoms: patSymptoms?.value?.trim() || ""
      },
      fee: currentDoctor.fee,
      status: "Confirmed"
    };

    // store into localStorage
    const arr = JSON.parse(localStorage.getItem("appointments") || "[]");
    arr.unshift(appt);
    localStorage.setItem("appointments", JSON.stringify(arr));

    // show confirmation summary
    showConfirmation(appt);
    closeModal();
    renderUpcoming();
  });
}

/* show toast / confirm */
function showConfirmation(appt) {
  if (!confirmToast) return;
  // 🆕 FIX: Use backticks for template literal
  confirmToast.textContent = `✅ Appointment booked with ${appt.doctorName} on ${new Date(appt.date).toLocaleString('en-US')}`;
  confirmToast.classList.remove("hidden");
  setTimeout(() => confirmToast.classList.add("hidden"), 4500);
}

/* Upcoming appointments */
function renderUpcoming() {
  if (!upcomingList) return;
  const arr = JSON.parse(localStorage.getItem("appointments") || "[]");
  upcomingList.innerHTML = "";
  if (arr.length === 0) {
    // 🆕 FIX: Use string for innerHTML (not JSX)
    upcomingList.innerHTML = '<p class="muted">No upcoming appointments</p>';
    return;
  }
  arr.forEach(a => {
    const el = document.createElement("div");
    el.className = "appt";
    // 🆕 FIX: Use backticks for template literal in innerHTML
    el.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong>${a.doctorName}</strong>
          <div class="muted" style="font-size:13px">${a.specialization} • ${a.consultType}</div>
          <div style="font-size:13px;margin-top:6px">${new Date(a.date).toLocaleString('en-US')}</div>
        </div>
        <div style="text-align:right">
          <div style="color:var(--purple);font-weight:600">₹ ${a.fee}</div>
          <div style="margin-top:8px">
            <button class="btn ghost" onclick="reschedule('${a.id}')">Reschedule</button>
            <button class="btn" onclick="cancelAppt('${a.id}')">Cancel</button>
          </div>
        </div>
      </div>
    `;
    upcomingList.appendChild(el);
  });
}

/* cancel / reschedule (simple) */
function cancelAppt(id) {
  if (!confirm("Cancel appointment?")) return;
  let arr = JSON.parse(localStorage.getItem("appointments") || "[]");
  arr = arr.filter(a => a.id !== id);
  localStorage.setItem("appointments", JSON.stringify(arr));
  renderUpcoming();
  alert("Appointment cancelled.");
}

function reschedule(id) {
  alert("Reschedule flow not implemented in demo. Open booking to create new appointment.");
}

/* utility listeners */
const goDashboardEl = document.getElementById("goDashboard");
if (goDashboardEl) goDashboardEl.addEventListener("click", () => location.href = "dashboard.html");

const globalSearchEl = document.getElementById("globalSearch");
if (globalSearchEl) globalSearchEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") renderDoctors();
});

/* initial render */
buildFilterChips();
renderDoctors();
renderUpcoming();
