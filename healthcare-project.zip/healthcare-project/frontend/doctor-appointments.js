// Dummy data (from dashboard + additional)
const appointments = [
  { name: "Ravi Kumar", date: "2025-10-10", time: "10:00 AM", type: "In-person", status: "Confirmed", details: { age: 32, gender: "Male", symptoms: "Chest pain" } },
  { name: "Sneha Patil", date: "2025-10-10", time: "11:30 AM", type: "Online", status: "Pending", details: { age: 27, gender: "Female", symptoms: "Headache" } },
  { name: "Kiran Desai", date: "2025-10-10", time: "1:00 PM", type: "In-person", status: "Completed", details: { age: 40, gender: "Male", symptoms: "Fever" } },
  { name: "Meena Reddy", date: "2025-10-10", time: "3:00 PM", type: "Online", status: "Completed", details: { age: 29, gender: "Female", symptoms: "Cold" } },
  { name: "Arjun Rao", date: "2025-10-10", time: "5:00 PM", type: "In-person", status: "Confirmed", details: { age: 36, gender: "Male", symptoms: "Cough" } }
];

const tableBody = document.getElementById("appointmentTable");
const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");

// Display appointments
function renderAppointments(data) {
  tableBody.innerHTML = "";
  data.forEach((app, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${app.name}</td>
      <td>${app.date}, ${app.time}</td>
      <td>${app.type}</td>
      <td><span class="status ${app.status}">${app.status}</span></td>
      <td>
        <button class="action-btn" onclick="viewDetails(${index})">View</button>
        <button class="action-btn" onclick="markCompleted(${index})">Complete</button>
        <button class="action-btn" onclick="cancelAppointment(${index})">Cancel</button>
      </td>
    `;
    tableBody.appendChild(row);
  });
}

// Filter by search or status
function applyFilters() {
  const searchValue = searchInput.value.toLowerCase();
  const statusValue = statusFilter.value;

  const filtered = appointments.filter(
    (a) =>
      a.name.toLowerCase().includes(searchValue) &&
      (statusValue === "All" || a.status === statusValue)
  );
  renderAppointments(filtered);
}

searchInput.addEventListener("input", applyFilters);
statusFilter.addEventListener("change", applyFilters);

// Action buttons
function viewDetails(index) {
  const app = appointments[index];
  document.getElementById("modalName").innerText = app.name;
  document.getElementById("modalAge").innerText = app.details.age;
  document.getElementById("modalGender").innerText = app.details.gender;
  document.getElementById("modalSymptoms").innerText = app.details.symptoms;
  document.getElementById("detailsModal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("detailsModal").classList.add("hidden");
}

function markCompleted(index) {
  appointments[index].status = "Completed";
  applyFilters();
}

function cancelAppointment(index) {
  appointments[index].status = "Cancelled";
  applyFilters();
}

// Navigation + logout
function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Doctor logged out successfully!");
  window.location.href = "auth.html";
}

// Initialize
renderAppointments(appointments);