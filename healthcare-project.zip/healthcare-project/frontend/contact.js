// 🏥 Dummy Hospital Data
const hospitals = [
  {
    name: "CityCare Hospital",
    address: "MG Road, Bengaluru",
    phone: "+91 98765 43210",
    email: "citycare@gmail.com",
    website: "www.citycare.in",
  },
  {
    name: "LifePlus Multispeciality",
    address: "Jayanagar, Bengaluru",
    phone: "+91 87654 32109",
    email: "contact@lifeplus.in",
    website: "www.lifeplus.in",
  },
  {
    name: "Nova Health Clinic",
    address: "Indiranagar, Bengaluru",
    phone: "+91 99887 77665",
    email: "support@novahealth.in",
    website: "www.novahealth.in",
  },
  {
    name: "Aster Hospital",
    address: "Hebbal, Bengaluru",
    phone: "+91 98800 11223",
    email: "care@aster.in",
    website: "www.aster.in",
  },
  {
    name: "Sunshine Medical Center",
    address: "Koramangala, Bengaluru",
    phone: "+91 97890 54321",
    email: "help@sunshine.in",
    website: "www.sunshine.in",
  },
];

// Render hospitals
const hospitalContainer = document.getElementById("hospitalContainer");
const hospitalSelect = document.getElementById("hospitalSelect");

if (hospitalContainer) {
  hospitals.forEach((h) => {
    // Backticks already present – no change needed
    const card = `
      <div class="hospital-card">
        <h3>${h.name}</h3>
        <p>📍 ${h.address}</p>
        <p>📞 ${h.phone}</p>
        <p>✉ <a href="mailto:${h.email}">${h.email}</a></p>
        <p>🌐 <a href="https://${h.website}" target="_blank">${h.website}</a></p>
      </div>
    `;
    hospitalContainer.innerHTML += card;
  });
}

if (hospitalSelect) {
  hospitals.forEach((h) => {
    // Add to dropdown
    const option = document.createElement("option");
    option.value = h.name;
    option.textContent = h.name;
    hospitalSelect.appendChild(option);
  });
}

// 💌 Contact form handling
const contactForm = document.getElementById("contactHospitalForm");
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("userName")?.value?.trim() || "";
    const email = document.getElementById("userEmail")?.value?.trim() || "";
    const hospital = document.getElementById("hospitalSelect")?.value?.trim() || "";
    const message = document.getElementById("userMessage")?.value?.trim() || "";

    if (!name || !email || !hospital || !message) {
      alert("⚠ Please fill out all fields before submitting.");
      return;
    }

    // 🆕 FIX: Added backticks for template literal in alert
    alert(`✅ Message sent successfully to ${hospital}!`);
    e.target.reset();
  });
}
