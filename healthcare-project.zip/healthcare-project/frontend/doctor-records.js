const patientRecords = [
  { name: "Ravi Kumar", age: 32, gender: "Male", lastVisit: "2025-10-08", diagnosis: "Chest Pain", notes: "Advised ECG", prescription: "Aspirin 75mg" },
  { name: "Sneha Patil", age: 27, gender: "Female", lastVisit: "2025-10-05", diagnosis: "Migraine", notes: "Rest & hydration", prescription: "Sumatriptan" },
  { name: "Kiran Desai", age: 40, gender: "Male", lastVisit: "2025-10-02", diagnosis: "Fever", notes: "Prescribed Paracetamol", prescription: "Paracetamol 500mg" }
];

const recordsTable = document.getElementById("recordsTable");
const modal = document.getElementById("recordModal");

function renderRecords() {
  if (!recordsTable) return; // Safety check
  recordsTable.innerHTML = "";
  patientRecords.forEach((rec, index) => {
    const row = document.createElement("tr");
    // Backticks already present – no change needed
    row.innerHTML = `
      <td>${rec.name}</td>
      <td>${rec.age}</td>
      <td>${rec.gender}</td>
      <td>${rec.lastVisit}</td>
      <td>${rec.diagnosis}</td>
      <td><button class="action-btn" onclick="viewRecord(${index})">View</button></td>
    `;
    recordsTable.appendChild(row);
  });
}

let currentIndex = null;

function viewRecord(index) {
  if (index < 0 || index >= patientRecords.length) {
    console.error(`Invalid index: ${index}`);
    return;
  }
  currentIndex = index;
  const rec = patientRecords[index];
  const mNameEl = document.getElementById("mName");
  const mAgeEl = document.getElementById("mAge");
  const mGenderEl = document.getElementById("mGender");
  const mVisitEl = document.getElementById("mVisit");
  const mDiagnosisEl = document.getElementById("mDiagnosis");
  const mNotesEl = document.getElementById("mNotes");
  const mPrescriptionEl = document.getElementById("mPrescription");
  if (mNameEl) mNameEl.textContent = rec.name;
  if (mAgeEl) mAgeEl.textContent = rec.age;
  if (mGenderEl) mGenderEl.textContent = rec.gender;
  if (mVisitEl) mVisitEl.textContent = rec.lastVisit;
  if (mDiagnosisEl) mDiagnosisEl.textContent = rec.diagnosis;
  if (mNotesEl) mNotesEl.value = rec.notes;
  if (mPrescriptionEl) mPrescriptionEl.value = rec.prescription;
  if (modal) modal.classList.remove("hidden");
}

function closeModal() {
  if (modal) modal.classList.add("hidden");
  currentIndex = null; // Reset
}

function saveNotes() {
  if (currentIndex === null || currentIndex < 0 || currentIndex >= patientRecords.length) {
    alert("⚠ No record selected.");
    return;
  }
  const mNotesEl = document.getElementById("mNotes");
  const mPrescriptionEl = document.getElementById("mPrescription");
  if (mNotesEl) patientRecords[currentIndex].notes = mNotesEl.value;
  if (mPrescriptionEl) patientRecords[currentIndex].prescription = mPrescriptionEl.value;
  alert("💾 Notes saved successfully!");
  closeModal();
  renderRecords(); // Refresh table if needed
}

function downloadPDF() {
  const pdfContentEl = document.getElementById("pdfContent");
  if (!pdfContentEl) {
    console.error("PDF content element not found.");
    alert("⚠ PDF content not available.");
    return;
  }
  const mNameEl = document.getElementById("mName");
  if (!mNameEl || !mNameEl.textContent) {
    console.error("Patient name not found for PDF.");
    alert("⚠ Patient name not available for PDF.");
    return;
  }
  const opt = {
    margin: 0.5,
    // 🆕 FIX: Added backticks for template literal in filename
    filename: `${mNameEl.textContent}_Record.pdf`,
    image: { type: "jpeg", quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: "in", format: "a4", orientation: "portrait" }
  };
  // Assume html2pdf is loaded – if not, add <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script> to HTML
  html2pdf().from(pdfContentEl).set(opt).save().catch(err => {
    console.error("PDF generation error:", err);
    alert("⚠ Failed to generate PDF. Check console for details.");
  });
}

function openPage(page) {
  window.location.href = page;
}

function logout() {
  alert("Doctor logged out successfully!");
  window.location.href = "auth.html";
}

// Initial render
renderRecords();
